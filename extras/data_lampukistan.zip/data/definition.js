// DEFINITIONEN


///////////////////////////////////////////////////////////////////////
// ALLGEMEINE/EINFACHE EINSTELLUNGEN:


// FRAGENKATALOG
var fileQuestions = "Fragen.csv";


// LISTE DER PARTEIEN/KANDIDATEN (bitte mit Komma trennen, Reihenfolge beachten und mit "" umschliessen)
// Liste der Parteipositionen und Begruendungen
var strPartyFiles = "Barodscheff_Junior.csv, Oekonomen.csv, Philosophen.csv, Techniker.csv, Wladimir_Iljitsch_Uljanow.csv";
// Liste der Parteinamen - kurz 
var strPartyNamesShort = "Barodscheff Jr., Wirtschaft, Philosophie, Technik, W.I. Uljanow";
// Liste der Parteinamen - lang
var strPartyNamesLong = "Barodscheff Junior - Sohn des gro&szlig;en F&uuml;hrers von Lampukistans, Wirtschaftsfakult&auml;t der J.B. Uni, Philosophische Fakult&auml;t der J.B. Uni, Technische Fakult&auml;t der J.B. Uni, Wladimir Iljitsch Uljanow - Revolutionsf&uuml;hrer";
// Logos der Parteien (sollten im Format 50x25px sein)
var strPartyLogosImg = "barodjr.jpg, econ.jpg, phil.jpg, tech.jpg, wiu.jpg";
var intPartyLogosImgWidth = 50;
var intPartyLogosImgHeight = 25;
// Internetseiten der Parteien/Kandidaten ohne http://
var strPartyInternet = "www.Barodscheff-Junior.la, econ.barodscheff-uni.edu.la, phil.barodscheff-uni.edu.la, tech.barodscheff-uni.edu.la, de.wikipedia.org/wiki/Lenin";
// Anzahl der Parteien, die in der detaillierten Auswertung sofort angezeigt werden sollen. 0 = alle 
var intPartyDefaultShow = 4


// UeBERSCHRIFTEN UND TEXTE
// Hauptueberschrift
var heading1 = "StuPa/StuRa-Wahlen";
// zweite Ueberschrift
var heading2 = "Die Wahl zum neuen Studentenparlament/Studentenrat der Joltawan-Barodscheff-Universität in Porada Ninfu";
// Kurzer Text um was es bei der Wahl geht
var explainingText = "Vom 2. bis 4. Mai finden an der Joltawan-Barodscheff-Universität in Porada Ninfu Wahlen zur neuen Studentenvertretung statt. Es treten verschiedene Listen und Einzelkandidaten an. Die Hochschulleitung hofft, dass die Wahlbeteiligung auch diesmal bei über 95% liegen wird."; 


// IMPRESSUM, KONTAKT
// (optional) Redaktion: Person(en), die die Fragen ausgearbeitet hat
var imprintEditorialNames = "Studentenvertretung der Universit&auml;t Porada Ninfu";
// (optional) Redaktion: Kontakt-E-mail
var imprintEditorialEmail = "info@barodscheff-uni.edu.la";
 // (optional) Technik: Person(en), die das System aufgesetzt hat
var imprintTechnicsNames = "Informatikabteilung der  Universität Porada Ninfu";
 // (optional) Technik: Kontakt-E-mail
var imprintTechnicsEmail = "informatik@barodscheff-uni.edu.la";
// (optional) Quellenangaben zu den Bildern
var imprintPictures = "Wikimedia, Bundesarchiv Bild 183-71043-0003"; 
// (optional) Link zu einer Datenschutzerklaerung ohne http:// - erlaubt die anonyme Statistik
var imprintPrivacyUrl = "www.barodscheff-uni.edu.la/cms/privacy.php"; 



///////////////////////////////////////////////////////////////////////
// ERWEITERTE EINSTELLUNGEN:

// Trennzeichen fuer die CSV-Dateien (Excel benutzt haeufig Semikolon, OpenOffice ein Komma)
var separator = ",";

// Designvorlage (CSS) im Ordner /styles 
var design = "default";

// (To Do) Sprache
var language = "de";



///////////////////////////////////////////////////////////////////////
// PROFESSIONELLE EINSTELLUNGEN:


// STATISTIK
// Anonyme Auswertung zulassen: true/1 oder false/0 
// Die Einwilligung des Nutzers und eine Datenschutzerklaerung (s.o.) werden benoetigt!
// Als Ergebnis erhaelt man die Liste mit der persoenlichen Auswahl in der Variablen "mowpersonal" (-1,0,1) 
// und die Liste mit der Anzahl der Uebereinstimmungen mit den Parteien als "mowparties" (5,1,0,2) zurueck.
// Als Trennzeichen fuer die Werte dient wieder ein Komma ;-)
// Das Skript und der Mat-O-Wahl sollten auf der gleichen Domain liegen. 
var statsRecord = 0;
var statsServer = "http://localhost/Test/vote.php";
