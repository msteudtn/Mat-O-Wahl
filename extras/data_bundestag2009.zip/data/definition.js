// DEFINITIONEN


///////////////////////////////////////////////////////////////////////
// ALLGEMEINE/EINFACHE EINSTELLUNGEN:


// FRAGENKATALOG
var fileQuestions = "Fragen2.csv";


// LISTE DER PARTEIEN/KANDIDATEN (bitte mit Komma trennen, Reihenfolge beachten und mit "" umschliessen)
// Liste der Parteipositionen und Begruendungen
var strPartyFiles = "cdu-csu.csv, spd.csv, fdp.csv, linke.csv, b90gruene.csv, piraten.csv";
// Liste der Parteinamen - kurz 
var strPartyNamesShort = "CDU/CSU, SPD, FDP, Linke, B90/Grüne, Piraten";
// Liste der Parteinamen - lang
var strPartyNamesLong = "Christlich Demokratische Union Deutschlands / Christlich-Soziale Union in Bayern e.V., Sozialdemokratische Partei Deutschlands, Freie Demokratische Partei, Die Linke, Bündnis 90/Die Grünen, Piratenpartei Deutschland";
// Logos der Parteien (sollten im Format 50x25px sein)
var strPartyLogosImg = "cdu-csu.png, spd.png, fdp.png, linke.png, b90gruene.png, piraten.png";
var intPartyLogosImgWidth = 50;
var intPartyLogosImgHeight = 25;
// Internetseiten der Parteien/Kandidaten ohne http://
var strPartyInternet = "www.cducsu.de/, www.spd.de/, www.liberale.de/, www.die-linke.de/, www.gruene.de/, www.piratenpartei.de/";
// Anzahl der Parteien, die in der detaillierten Auswertung sofort angezeigt werden sollen. 0 = alle 
var intPartyDefaultShow = 5


// UeBERSCHRIFTEN UND TEXTE
// Hauptueberschrift
var heading1 = "Bundestagswahl 2009";
// zweite Ueberschrift
var heading2 = "Parteien mit mindestens 2% Stimmen.";
// Kurzer Text um was es bei der Wahl geht
var explainingText = "Am 27. September fand die Wahl zum Deutschen Bundestag statt. Sie k&ouml;nnen sich hier alle Parteipositionen (ohne Begr&uuml;ndungen) anschauen und miteinander vergleichen."; 


// IMPRESSUM, KONTAKT
// (optional) Redaktion: Person(en), die die Fragen ausgearbeitet hat
var imprintEditorialNames = "Bundeszentrale f&uuml;r politische Bildung";
// (optional) Redaktion: Kontakt-E-mail
var imprintEditorialEmail = "";
 // (optional) Technik: Person(en), die das System aufgesetzt hat
var imprintTechnicsNames = "Mat-O-Wahl";
 // (optional) Technik: Kontakt-E-mail
var imprintTechnicsEmail = "";
// (optional) Quellenangaben zu den Bildern
var imprintPictures = ""; 
// (optional) Link zu einer Datenschutzerklaerung ohne http:// - erlaubt die anonyme Statistik
var imprintPrivacyUrl = "";



///////////////////////////////////////////////////////////////////////
// ERWEITERTE EINSTELLUNGEN:

// Trennzeichen fuer die CSV-Dateien (Excel benutzt haeufig Semikolon, OpenOffice ein Komma)
var separator = ",";

// Designvorlage (CSS) im Ordner /styles 
var design = "default";

// (To Do) Sprache
var language = "de";



///////////////////////////////////////////////////////////////////////
// PROFESSIONELLE EINSTELLUNGEN:


// STATISTIK
// Anonyme Auswertung zulassen: true/1 oder false/0 
// Die Einwilligung des Nutzers und eine Datenschutzerklaerung (s.o.) werden benoetigt!
// Als Ergebnis erhaelt man die Liste mit der persoenlichen Auswahl in der Variablen "mowpersonal" (-1,0,1) 
// und die Liste mit der Anzahl der Uebereinstimmungen mit den Parteien als "mowparties" (5,1,0,2) zurueck.
// Als Trennzeichen fuer die Werte dient wieder ein Komma ;-)
// Das Skript und der Mat-O-Wahl sollten auf der gleichen Domain liegen. 
var statsRecord = 0;
var statsServer = "http://localhost/Test/vote.php";
