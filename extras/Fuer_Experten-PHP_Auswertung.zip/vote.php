<?php

// --------------------------------------------------------------------
// ALLGEMEINES
//
// Dies ist ein sehr simples Beispiel zur Auswertung der abgegebenen Stimmen.
// Die Routine zum Schreiben der Datei stammt von http://de3.php.net/manual/de/function.fwrite.php
// Wie in der definition.js erwaehnt, erhaelt das Skript zwei Variablen:
// "mowpersonal" und "mowparties"
// http://localhost/extras/vote.php?mowpersonal=-1,0,1,99&mowparties=5,1,0,2
// Diese werden hier zusammen mit dem Unix-Zeitstempel abgespeichert.
//
// Sie koennen (sollten!) Daten stattdessen auch in einer Datenbank (z.B. MySQL) ablegen.
// Siehe "moegliche Probleme" am Ende dieser Datei.

// --------------------------------------------------------------------
// RECHTLICHES
// 
// Muster-Erklärungen für den Datenschutz finden Sie z.B. auf:
// http://www.e-recht24.de/muster-disclaimer.htm 
// oder http://www.datenschutz-generator.de/
// 
// Einen Blick Wert ist auch die Datenschutz-Erklärung von https://www.lokal-o-mat.de/tool/ahlen/
// "Bei der Nutzung von lokal-o-mat werden für die Dauer Verbindungsdaten wie die IP-Adresse der Nutzer übermittelt. Diese Daten werden nur zum Zweck des Verbindungsaufbaus verwendet.
// Die Nutzungsdaten einschließlich der angekreuzten Antworten der Nutzer werden zu statistischen und wissenschaftlichen Zwecken gespeichert. Dazu werden diese Daten vor der Speicherung anonymisiert, so dass ein Personenbezug nicht mehr hergestellt werden kann.
// Darüberhinaus werden keinerlei personenbezogene Daten bei der Nutzung des lokal-o-mat gespeichert."

// --------------------------------------------------------------------
// SKRIPT

// Dateiname fuer Ergebnisse
$filename = 'test.txt';


// IP-Adresse des Besuchers
	if (getenv(HTTP_X_FORWARDED_FOR))
		{
		$ip=getenv(HTTP_X_FORWARDED_FOR);
		}
	else
		{
		$ip=getenv(REMOTE_ADDR);
		}

	$ip = explode (',', $ip);
	$ip = $ip[0];

// Wenn keine IP gespeichert werden soll, einfach die folgende Zeile auskommentieren.
// Hierbei wird das soeben erhaltene Ergebnis von "$ip" mit einem "Null-Wert" überschrieben 
// aber das Format für die simple Auswertung (results.html) bleibt erhalten.
//
// $ip="0.0.0.0";


// Daten in Datei schreiben und einzelne Elemente mit Leerzeichen trennen
// Format: IP-ADRESSE UNIX-ZEITSTEMPEL MOWPERSONAL MOWPARTIES
// also:   IP-ADRESSE UNIX-ZEITSTEMPEL M,O,W,P,E,R,S,O,N,A,L M,O,W,P,A,R,T,I,E,S
$somecontent = "\n".$ip." ".time()." ".$_GET["mowpersonal"]." ".$_GET["mowparties"];

// Sichergehen, dass die Datei existiert und beschreibbar ist
if (is_writable($filename)) {

    // Wir öffnen $filename im "Anhängen" - Modus.
    // Der Dateizeiger befindet sich am Ende der Datei, und
    // dort wird $somecontent später mit fwrite() geschrieben.
    if (!$handle = fopen($filename, "a")) {
         print "Kann die Datei $filename nicht öffnen";
         exit;
    }

    // Schreibe $somecontent in die geöffnete Datei.
    if (!fwrite($handle, $somecontent)) {
        print "Kann in die Datei $filename nicht schreiben";
        exit;
    }

    print "Fertig, in Datei $filename wurde $somecontent geschrieben";

    fclose($handle);

} else {
    print "Die Datei $filename ist nicht schreibbar";
}

// --------------------------------------------------------------------
// MOEGLICHE PROBLEME
// 
// Die Datei kann nicht geoeffnet / geschrieben werden 
// Ursache: fehlende Dateizugriffsrechte unter Unix/Linux
// Lösung: Rechte setzen, 664 sollte klappen, 777 klappt garantiert, ist aber bedenklich
// 
// Die Daten wurden nicht richtig uebertragen / eingetragen, z.B.
// RICHTIG: 127.0.0.1 1254322473 1,1,-1,-1,-1,1 2,5,5,0
// FEHLER:  127.0.0.11254322473 1,1,-1,-1,-1,1 2,5,5,0
// FEHLER:  127.0.0.1 1254322473 1,1,-1,,, 2,5,5,0
// FEHLER:  127.0.0.1 1254322473 ,,,,, 2,5,5,0
// FEHLER:  127.0.0.1 1254322473  2,5,5,0
// FEHLER:  127.0.0.1 1254322473   
// Ursache: unbekannt
// Lösung: Datenbank benutzen (z.B. MySQL) oder die Datei regelmaessig manuell sichern und pruefen
// 

?> 
